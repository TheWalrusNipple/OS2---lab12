
package com.fluendo.player;

class Configure
{
  public String buildInfo = "Built on 2010-03-19 18:47:18 GMT (version 0.6.0) in debug mode.";

  public String buildDate = "2010-03-19 18:47:18 GMT";
  public String buildVersion = "0.6.0";
  public String buildType = "debug";
  public String revision = "0.6.0";
  public String branch = "Xiph";

  public Configure() {
  }
}
    