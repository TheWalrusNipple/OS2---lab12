package com.fluendo.jst;

public class SourceInfo
{
  public String revision = "0.6.0";
  public String branch = "Xiph";

  public SourceInfo() {
  }
}
